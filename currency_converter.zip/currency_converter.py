file="currency_converter\currency rate.txt"
with open(file) as d:
    currency=d.readlines()
dictionary={}
for i in currency:
    data=i.split('\t')
    dictionary[data[0].lower()]=float(data[1])
a=int(input("enter amount : "))
curr=input("enter currency which you have : ")
c=input("enter currency you want to convert to : ")
usd=(a*float(dictionary[c]))
x=(usd/float(dictionary[curr]))
print(x)